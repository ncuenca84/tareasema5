// src/app/models/prestamo.ts
export interface Prestamo {
  id: number;
  cliente: string;
  monto: number;
  fecha: string;
}